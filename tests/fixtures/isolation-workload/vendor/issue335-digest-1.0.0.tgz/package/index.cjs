exports.digest = (data) => require('node:crypto').createHash('sha256').update(data).digest('hex');
